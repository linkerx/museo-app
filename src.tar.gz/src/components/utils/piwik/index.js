var PiwikReactRouter = require('piwik-react-router');

module.exports = new PiwikReactRouter({
  url: 'http://stats.emmanozzi.org',
  siteId: 1
});

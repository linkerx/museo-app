var PiwikReactRouter = require('piwik-react-router');

module.exports = new PiwikReactRouter({
  url: 'https://stats.emmanozzi.org',
  siteId: 1
});

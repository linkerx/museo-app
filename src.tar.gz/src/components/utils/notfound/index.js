var React = require('react');

function NotFound(){
  return (
    <div>NotFound</div>
  )
}

module.exports = NotFound;

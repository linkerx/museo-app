var React = require('react');
require('./styles.less')

function FooterFoot(props) {
  return (
    <div className='footer-foot'>
      Museo Emma Nozzi - 2017 - hecho por: <a target='_blank' href='https://www.linkedin.com/in/linkerx/'>Diego Martinez Diaz</a>
    </div>
  )
}

module.exports = FooterFoot;

var React = require('react');

function Objeto(props){
  return (<div></div>)
}

module.exports = Objeto;

var React = require('react');

function Objetos(props){
  return (<div></div>)
}

module.exports = Objetos;
